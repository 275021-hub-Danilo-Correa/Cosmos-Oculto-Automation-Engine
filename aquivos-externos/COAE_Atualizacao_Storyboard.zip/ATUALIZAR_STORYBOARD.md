# Atualização de storyboard — restaurar e desmembrar

Base: Cosmos-Oculto-Automation-Engine-main(3).zip enviado pelo usuário.

## Aplicar no Codespaces

1. Baixe o backup do projeto pelo COAE, se fez novas alterações.
2. Pare o servidor com Ctrl+C.
3. Envie COAE_Atualizacao_Storyboard.zip para a pasta que contém iniciar.py.
4. Execute na mesma pasta:

```bash
python -m zipfile -e COAE_Atualizacao_Storyboard.zip .
.venv/bin/python -m unittest discover -s tests -q
.venv/bin/python iniciar.py --host 0.0.0.0 --port 8765 --no-browser
```

5. Abra a porta 8765 com o novo token exibido no terminal. Se necessário, recarregue com Ctrl+Shift+R.

O pacote atualiza apenas coae/application.py, coae/server.py, coae/web/app.js, docs/PROJECT_STATE.md e adiciona tests/test_story_history.py. Não inclui banco, áudio nem .env. As correções de Gemini e de exportação SQLite do ZIP (3) foram mantidas. Se editou esses arquivos depois do envio, compare antes de substituir.

## Recuperar seu projeto

Abra COAE-BA0592A3 → Storyboard. Em Restaurar uma versão anterior, selecione v2 · 8 cenas e clique Restaurar versão selecionada. Confirme. Será criada uma nova versão (v11 se a atual ainda for v10), sem apagar o histórico. A v2 tinha descrições vazias: elas continuarão precisando ser preenchidas; a descrição da cena única da v10 não é distribuída automaticamente entre as oito cenas.

Não clique em Analisar áudio novamente. Não é preciso configurar Gemini para restaurar.

## Desmembrar

O botão Desmembrar por frases e pausas refaz as divisões de todo o storyboard usando a transcrição salva. É local e não consome API. Não garante todas as cenas abaixo de determinada duração: a divisão respeita pontuação e pausas. Para um ajuste pontual, use Dividir pela fala no cartão da cena.

A divisão por frases reinicia descrições. Restaurar preserva as descrições da versão escolhida. Ambas exigem nova revisão/aprovação e invalidam o uso automático das imagens da versão anterior; arquivos anteriores continuam preservados.

52 testes passaram. Também foram testados os controles via JSDOM/HTTP e a restauração/divisão em uma cópia do seu backup real. Não foi alterado seu Codespaces nem publicado commit no GitHub nesta entrega.
