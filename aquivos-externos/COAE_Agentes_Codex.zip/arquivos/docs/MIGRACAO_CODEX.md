# Registro da migração para Codex

Aplicação: COAE. Base: ZIP main(4) e revisão de especialistas entregue posteriormente.
Esta atualização pode ser integrada tanto com quanto sem o pacote anterior:
os perfis nativos e o AGENTS.md aqui estão completos. Não aplicar patches antigos
por cima para evitar restaurar a documentação baseada no Copilot.

Arquivos novos: seis .codex/agents/coae_*.toml e configuração opcional de concorrência.
Arquivos de orientação: AGENTS.md e docs/AGENTES.md revisados. Nenhum .env ou código
Python/JS foi alterado. Perfis .github/agents antigos não foram removidos automaticamente.
A seção de agentes do PROJECT_STATE existente deve apontar para docs/AGENTES.md;
não substituir o histórico inteiro durante a integração.

Validação feita: estrutura TOML, seis nomes, campos e links locais. Não há executável
Codex neste ambiente para verificar descoberta ou iniciar uma sessão real.
Próximo teste: nova sessão Codex no repositório, inspeção dos agentes disponíveis e
uma revisão curta com coae_qa, sem geração de imagens ou instalação de modelos.

Depois: continuar desenvolvimento do domínio coae_local_ai; GPU e modelos apenas
no PC de casa. Nenhuma mudança desta entrega foi enviada ao GitHub.
