# Estado do projeto · v0.2

## Implementado

- Pacote externo `Cosmos_Oculto_GitHub_Continuacao.zip` integrado como nova base do repositório.
- Pacote `coae`, CLI e entidades originais preservados e atualizados de forma aditiva.
- Migração aditiva SQLite, integridade, versionamento e invalidação de dependências.
- Interface local em sete áreas: visão geral, roteiro, áudio, storyboard, imagens, exportação e auditorias.
- Roteiro editável, fontes fornecidas pelo usuário, auditoria e correção limitada opcional com Gemini.
- Exportação para Dark Planner com pausas preservadas. Nenhuma geração de voz.
- Ingestão real WAV/MP3/M4A, duração medida, originais preservados e vínculo ao roteiro.
- Provider local faster-whisper com timestamps de palavras; importação assistida de JSON também disponível.
- Propostas locais por frase/pausa; agrupamento semântico opcional por Gemini, com tempos definidos pelo código.
- Edição, divisão/união e aprovação de storyboard; timeline visual contínua sem duração fixa.
- Descrições visuais, geração Gemini, importação de imagens, auditoria multimodal e correção limitada.
- Exportação de prompts, imagens, áudio, timeline JSON/CSV e legendas SRT/VTT para montagem manual.
- Histórico de tarefas/auditorias, limites por chamada e retomada de resultados persistidos.
- Bundle de projeto inclui snapshot consistente de `data/coae.sqlite3`, `BACKUP_README.txt`, artefatos e `project_state.json`.

## Validação realizada

FFmpeg 6.1.1/ffprobe foram instalados no ambiente Linux. O `.venv` do projeto foi criado com `faster-whisper 1.2.1` e `Pillow 12.3.0`.

35 testes Python passaram no workspace Linux **sem skips**, incluindo MP3 real via FFmpeg, o fluxo assistido com imagens de teste e a validação do snapshot SQLite no bundle. O pacote externo foi executado isoladamente antes da integração e passou pela mesma suíte anterior.

O provider `FasterWhisperProvider` foi executado com o modelo `tiny` em áudio falado sintético em português: carregou o modelo e produziu 9 segmentos com timestamps reais para um arquivo de 3,49 s. O texto reconhecido apresentou erros esperados da voz sintetizada; este teste valida a integração técnica, não a qualidade editorial da transcrição.

O smoke test HTTP local confirmou startup do servidor, carregamento do HTML do dashboard, bloqueio de `/api/state` sem token (`401`) e leitura autenticada do estado (`configured=false`, `ffprobe=false`). A compilação Python passou e os diagnósticos do workspace não apontaram erros.

O teste de MP3 real via FFmpeg foi reproduzido com sucesso. A importação e a análise de áudio real de usuário ainda não foram executadas; nenhum modelo Whisper foi baixado durante esta etapa.

O teste de bundle confirmou que o snapshot SQLite é legível e contém o projeto persistido. O bundle é uma cópia para análise/continuidade; ao mover o projeto para outra pasta, caminhos absolutos registrados no SQLite podem exigir rebase ou reimportação dos arquivos.

Não foram executadas chamadas pagas de IA, download/execução real de modelo de fala, Windows ou revisão visual com navegador completo. Não confundir testes de contrato, fixtures e dados sintéticos com aprovação de qualidade audiovisual.

## Próximas etapas concretas

1. Validar o faster-whisper com um áudio humano real de 2–3 minutos do usuário; o modelo `tiny` já está disponível no cache, e modelos maiores poderão ser baixados conforme a configuração.
2. Ajustar reconhecimento e limites semânticos após comparar as cenas com a escuta.
3. Validar instalação Windows e o fluxo de áudio no Windows.
4. Validar um modelo de imagem da conta do usuário com um pequeno lote e avaliar custo/qualidade.
5. Evoluir formatos editoriais configuráveis, ingestão dos documentos de regras, SEO e exportação/renderização de movimento, conforme prioridades.

A especificação COAE_SPEC.md preservada descreve também funcionalidades futuras. Os estados e capacidades efetivamente disponíveis são os deste documento e do README.


## Correção: verificar Gemini antes da análise

A análise com Gemini verifica, antes da transcrição, chave/modelos preenchidos, limite inteiro positivo com saldo de chamadas e inicialização local do SDK. A rota HTTP retorna o erro imediatamente, sem criar tarefa nem consumir o upload de transcrição. O serviço repete a proteção para chamadas diretas. A análise local continua independente do Gemini.

Validação desta correção: 43 testes passaram (35 existentes e 8 novos), incluindo preservação do banco e rejeição HTTP. Foi reproduzida a configuração ausente em uma cópia isolada do bundle real COAE-BA0592A3: não houve nova transcrição, versão ou chamada. O original não foi alterado.

Esta checagem é local: não autentica a chave remotamente, não garante acesso aos modelos nem reserva saldo para todos os lotes. Falhas remotas posteriores ainda podem deixar resultados parciais preservados. Nenhuma chamada paga foi executada nesta correção.
