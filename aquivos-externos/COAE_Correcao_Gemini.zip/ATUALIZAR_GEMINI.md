# Atualização: checar Gemini antes de transcrever

Aplique sobre a versão do repositório enviada em Cosmos-Oculto-Automation-Engine-main(2).zip.

1. Pare o servidor no Codespaces com Ctrl+C.
2. Envie COAE_Correcao_Gemini.zip para a raiz do repositório (a pasta de iniciar.py).
3. Extraia substituindo os arquivos do código:

```bash
python -m zipfile -e COAE_Correcao_Gemini.zip .
```

4. Execute os testes com o Python do seu ambiente:

```bash
.venv/bin/python -m unittest discover -s tests -q
```

5. Inicie novamente:

```bash
.venv/bin/python iniciar.py --host 0.0.0.0 --port 8765 --no-browser
```

Abra a porta 8765 com o novo #token mostrado no terminal.

O pacote substitui coae/application.py, coae/server.py, coae/provider.py, tests/test_regressions.py e docs/PROJECT_STATE.md. Não contém banco, áudio, projetos ou .env; preserva seus dados existentes. A mudança de backup SQLite da versão anterior foi mantida. Se você alterou esses arquivos depois do ZIP (2), compare antes de substituir.

## Teste esperado

Sem Gemini configurado, marcar Gemini e clicar em Analisar áudio e criar cenas mostra um aviso imediato, sem tarefa nova e sem modificar o storyboard. O mesmo ocorre com limite zero/esgotado, limite inválido ou SDK indisponível. Desmarcar Gemini mantém a análise local habilitada.

Não precisa reanalisar seu áudio para usar as cenas já existentes: após configurar Gemini, use Completar descrições com Gemini no storyboard atual.

43 testes passaram, além de reprodução em cópia do seu banco real, com preservação dos dados. Não foram realizadas chamadas pagas. A verificação não testa a validade da chave na internet nem garante saldo para todos os lotes; esses erros podem ocorrer posteriormente.
