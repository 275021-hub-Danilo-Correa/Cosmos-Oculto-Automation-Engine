# Estado do projeto · v0.2

## Implementado

- Continuação do repositório enviado, mantendo pacote `coae`, CLI e entidades originais.
- Migração aditiva SQLite, integridade, versionamento e invalidação de dependências.
- Interface local em sete áreas: visão geral, roteiro, áudio, storyboard, imagens, exportação e auditorias.
- Roteiro editável, fontes fornecidas pelo usuário, auditoria e correção limitada opcional com Gemini.
- Exportação para Dark Planner com pausas preservadas. Nenhuma geração de voz.
- Ingestão real WAV/MP3/M4A, duração medida, originais preservados e vínculo ao roteiro.
- Provider local faster-whisper com timestamps de palavras; importação assistida de JSON também disponível.
- Propostas locais por frase/pausa; agrupamento semântico opcional por Gemini, com tempos definidos pelo código.
- Edição, divisão/união e aprovação de storyboard; timeline visual contínua sem duração fixa.
- Descrições visuais, geração Gemini, importação de imagens, auditoria multimodal e correção limitada.
- Exportação de prompts, imagens, áudio, timeline JSON/CSV e legendas SRT/VTT para montagem manual.
- Histórico de tarefas/auditorias, limites por chamada e retomada de resultados persistidos.

## Validação realizada

34 testes Python passaram em Linux, incluindo MP3 real via FFmpeg. Fluxo assistido completo testado com áudio sintético e transcrição fornecida, imagens de teste, exports e reabertura. Smoke HTTP/DOM confirmou autenticação, startup JavaScript, criar projeto, salvar roteiro e sete áreas. Syntax check JavaScript passou.

Não foram executadas chamadas pagas de IA, download/execução real de modelo de fala, Windows ou revisão visual com navegador completo. Não confundir testes de contrato/mocks e dados sintéticos com aprovação de qualidade audiovisual.

## Próximas etapas concretas

1. Validar instalação Windows e um áudio real de 2–3 minutos do usuário.
2. Ajustar reconhecimento e limites semânticos após comparar cenas com a escuta.
3. Validar um modelo de imagem da conta do usuário com um pequeno lote e avaliar custo/qualidade.
4. Evoluir formatos editoriais configuráveis, ingestão dos documentos de regras, SEO e exportação/renderização de movimento, conforme prioridades.

A especificação COAE_SPEC.md preservada descreve também funcionalidades futuras. Os estados e capacidades efetivamente disponíveis são os deste documento e do README.
